# brinjal_leaf_spot > 2024-10-21 2:03pm
https://universe.roboflow.com/mefinalyear/brinjal_leaf_spot

Provided by a Roboflow user
License: CC BY 4.0

